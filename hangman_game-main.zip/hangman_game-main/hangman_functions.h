#include <iostream>
#include <vector>
using namespace std;
//declare functions
void greet();
void display_misses(int misses);
void display_status(std::vector<char> incorrect, string answer);
void end_game(string answer, string codeword);
